@extends('layouts.app')

@section('content')
<div style="margin:17px"><a type="button" class="btn btn-primary btn-lg" href="/posts/create">create Form</a></div>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Title</th>
      <th scope="col">slug</th>
      <th scope="col">Created by</th>
      <th scope="col">Content</th>
      <th scope="col">Created at</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    @foreach($posts as $index => $value)
    <tr>
      <th scope="row">{{$value['id']}}</th>
      <td>{{$value['title']}}</td>
      <td>{{$value['slug']}}</td>
      <td>{{$value->user->name}}</td>
      <td>{{$value['content']}}</td>
      <td>{{$value['created_at']->format('d/m/Y')}}</td>

      <td style="margin:2px"><a type="button" class="btn btn-primary btn-lg" href="{{route('posts.show',['post' => $value['id'] ])}}">View</a></td>
      <td>
        <form method="post" action="{{route('posts.destroy',['post' => $value['id']])}}">
          @csrf
          @method('delete')
          <button class="btn btn-danger btn-lg"  onclick="return confirm('are you sure?')" type="submit">Delete</button>
      </td>
      <td><a  class="btn btn-primary btn-lg" href="{{route('posts.edit',['post' => $value['id'] ])}}">edit</a>




      </td>

    </tr>
    @endforeach

  </tbody>
</table>
@endsection