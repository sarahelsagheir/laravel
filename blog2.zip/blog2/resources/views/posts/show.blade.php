@extends('layouts.app')
@section('content')



<div style="margin:50px;" class="card">
  <div class="card-header">
    Post Info
  </div>
  <div class="card-body">
    <h5 class="card-title">Title</h5>
    <p class="card-text">{{$post->title}}</p>
    <h5 class="card-title">Description</h5>
<p class="card-text">{{$post->content}}</p>
<h5 class="card-title">Post Creator</h5>

<p class="card-text">{{$post->user->name}}</p>


  </div>
</div>
@endsection