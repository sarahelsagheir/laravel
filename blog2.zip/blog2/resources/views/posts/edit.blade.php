@extends('layouts.app')

@section('content')
    <h1>Edit Post</h1>
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    <form method="POST" action="/posts/{{$post->id}}">
        @csrf
        @method('put')
        <div class="form-group">
          <label for="exampleInputEmail1">Title</label>
          <input name="title" type="text" class="form-control"  aria-describedby="emailHelp" value="{{$post->title}}">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Content</label>
          <input name="content" type="text" class="form-control" value="{{$post->content}}" >
        </div>

        <div class="form-group">

<label for="exampleInputPassword1">post Creator</label>

<input name="content" type="text" class="form-control" value="{{$post->user->name}}" >

</div>

        <button type="submit" class="btn btn-primary">update</button>
      </form>
@endsection