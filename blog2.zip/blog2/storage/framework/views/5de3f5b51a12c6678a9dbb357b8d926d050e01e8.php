<?php $__env->startSection('content'); ?>



<div style="margin:50px;" class="card">
  <div class="card-header">
    Post Info
  </div>
  <div class="card-body">
    <h5 class="card-title">Title</h5>
    <p class="card-text"><?php echo e($post->title); ?></p>
    <h5 class="card-title">Description</h5>
<p class="card-text"><?php echo e($post->content); ?></p>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog1/resources/views/posts/show.blade.php ENDPATH**/ ?>