<?php $__env->startSection('content'); ?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Title</th>
      <th scope="col">Content</th>

      <th scope="col">Created at</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($value['id']); ?></th>
      <td><?php echo e($value['title']); ?></td>
      <td><?php echo e($value['content']); ?></td>
      <td><?php echo e($value['created_at']); ?></td>

      <td style="margin:2px"><a type="button" class="btn btn-primary btn-lg" href="<?php echo e(route('posts.show',['post' => $value['id'] ])); ?>">View</a></td>
      <td>
        <form method="post" action="<?php echo e(route('posts.destroy',['post' => $value['id'] ])); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <button class="btn btn-danger btn-lg" type="submit">Delete</button>
      </td>
      <td><a  class="btn btn-primary btn-lg" href="<?php echo e(route('posts.edit',['post' => $value['id'] ])); ?>">edit</a>




      </td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog1/resources/views/posts/index.blade.php ENDPATH**/ ?>