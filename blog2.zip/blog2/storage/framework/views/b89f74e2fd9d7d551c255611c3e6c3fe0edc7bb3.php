<?php $__env->startSection('content'); ?>
    <h1>Edit Post</h1>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form method="POST" action="/posts/<?php echo e($post->id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="form-group">
          <label for="exampleInputEmail1">Title</label>
          <input name="title" type="text" class="form-control"  aria-describedby="emailHelp" value="<?php echo e($post->title); ?>">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Content</label>
          <input name="content" type="text" class="form-control" value="<?php echo e($post->content); ?>" >
        </div>

        <div class="form-group">

<label for="exampleInputPassword1">post Creator</label>

<input name="content" type="text" class="form-control" value="<?php echo e($post->user->name); ?>" >

</div>

        <button type="submit" class="btn btn-primary">update</button>
      </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/blog2/resources/views/posts/edit.blade.php ENDPATH**/ ?>