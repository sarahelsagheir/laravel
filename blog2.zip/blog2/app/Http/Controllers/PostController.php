<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\post; //require('app/Post')
use App\Http\Requests\StorePostRequest;


class PostController extends Controller
{
    function index()

    {


        return view('posts.index', [

            'posts' => Post::with('user')->get(),


        ]);

    }


    function create()
    {
        return view('posts.create');
    }
    public function store(StorePostRequest $request)

    {

        post::create([

            'title' => request()->title,
            'user_id' => request()->user()->id,
            'content' => request()->content,

        ]);

        return redirect()->route('posts.index');
    }
    function show($post)
    {

        $post = Post::find($post);
        return view('posts.show', ['post' => $post]);
    }
    function destroy($post)
    {
        $post = Post::find($post);
        $post->delete();
        return back();
    }
    function edit($post)
    {
        $post = Post::find($post);
        return view('posts.edit', ['post' => $post]);
    }

    function update($post,StorePostRequest $request)
    {

        Post::where('id', $post)
            ->update(['title' => request()->title, 'content' => request()->content]);
        return redirect()->route('posts.index');
    }
}
