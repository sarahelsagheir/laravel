<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\post;
use App\Http\Resources\PostResource;
class PostController extends Controller
{
    public function index()
    {
        return PostResource::collection(post::paginate(2));
    }

    public function show($id)
    {
        $post = post::find($id);

        return new PostResource($post);
    }
}
